char* concatestrings(char*, char*); 

char* addCharToString(char*, char);

int doesStringContainChar(char *, char);

int positionOfChar(char*, char);

char* getSubstring(char*, int, int);

int compare_strings(char* s1, char* s2);
